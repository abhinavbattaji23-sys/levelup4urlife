const KEY='levelup_v2_state';
const questData=[
 {id:'move',icon:'🏃',title:'Move your body',desc:'Choose safe movement: a walk, stretching, yoga, or your sport.',detail:'10–20 minutes · pick an age-appropriate pace',xp:100},
 {id:'read',icon:'📚',title:'Read something',desc:'Read a book, article, or a few pages of something useful.',detail:'15 minutes · learn one new thing',xp:75},
 {id:'focus',icon:'🎯',title:'Deep-focus session',desc:'Work on homework or a personal project without notifications.',detail:'20 minutes · one task at a time',xp:100},
 {id:'water',icon:'💧',title:'Take a water break',desc:'Pause your screen time and drink some water if you are thirsty.',detail:'A quick reset · no pressure to overdo it',xp:25},
 {id:'kind',icon:'🤝',title:'Do one helpful thing',desc:'Help at home, encourage someone, or do a small act of kindness.',detail:'Real-world impact · small things count',xp:75},
 {id:'create',icon:'🧠',title:'Create instead of scroll',desc:'Draw, write, build, practice music, or make something of your own.',detail:'15 minutes · progress over perfection',xp:100}
];
const achievements=[
 {id:'first',icon:'🚀',name:'First Move',desc:'Complete your first quest.',test:s=>s.completedTotal>=1},
 {id:'five',icon:'🖐️',name:'Quest Collector',desc:'Complete 5 quests in total.',test:s=>s.completedTotal>=5},
 {id:'ten',icon:'⚡',name:'Momentum',desc:'Complete 10 quests in total.',test:s=>s.completedTotal>=10},
 {id:'xp500',icon:'💚',name:'XP Builder',desc:'Earn 500 XP.',test:s=>s.xp>=500},
 {id:'xp1000',icon:'🏅',name:'Four Digits',desc:'Earn 1,000 XP.',test:s=>s.xp>=1000},
 {id:'streak3',icon:'🔥',name:'Three-Day Rhythm',desc:'Be active on 3 days.',test:s=>s.bestStreak>=3}
];
function today(){return new Date().toLocaleDateString('en-CA')}
function fresh(){return {name:'PLAYER ONE',xp:0,completedTotal:0,completedByDay:{},lastActive:null,streak:0,bestStreak:0,createdAt:today()}}
function load(){try{return {...fresh(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return fresh()}}
let state=load();
function save(){localStorage.setItem(KEY,JSON.stringify(state));renderShared()}
function levelFor(xp){return Math.floor(xp/500)+1}
function levelProgress(xp){return xp%500}
function currentDone(){return state.completedByDay[today()]||[]}
function currentQuests(){return questData.map(q=>({...q,done:currentDone().includes(q.id)}))}
function renderShared(){document.querySelectorAll('[data-player-name]').forEach(e=>e.textContent=state.name||'PLAYER ONE');document.querySelectorAll('[data-player-level]').forEach(e=>e.textContent=levelFor(state.xp));document.querySelectorAll('[data-player-xp]').forEach(e=>e.textContent=state.xp.toLocaleString());document.querySelectorAll('[data-player-streak]').forEach(e=>e.textContent=state.streak);document.querySelectorAll('[data-level-progress]').forEach(e=>e.style.width=(levelProgress(state.xp)/500*100)+'%');document.querySelectorAll('[data-level-label]').forEach(e=>e.textContent=`${levelProgress(state.xp)} / 500 XP to next level`);document.querySelectorAll('[data-quest-count]').forEach(e=>e.textContent=currentDone().length);document.querySelectorAll('[data-reward-progress]').forEach(e=>e.style.width=Math.min(100,state.xp/100000*100)+'%');document.querySelectorAll('[data-reward-xp]').forEach(e=>e.textContent=Math.min(state.xp,100000).toLocaleString());}
function toast(msg){let el=document.querySelector('.toast');if(!el)return;el.textContent=msg;el.style.display='block';clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>el.style.display='none',2300)}
function completeQuest(id){let q=questData.find(x=>x.id===id);if(!q||currentDone().includes(id))return;const wasToday=state.lastActive===today();state.completedByDay[today()]=[...currentDone(),id];state.xp+=q.xp;state.completedTotal+=1;if(!wasToday){let yesterday=new Date();yesterday.setDate(yesterday.getDate()-1);let y=yesterday.toLocaleDateString('en-CA');state.streak=state.lastActive===y?state.streak+1:1;state.lastActive=today();state.bestStreak=Math.max(state.bestStreak,state.streak)}save();renderPage();toast(`QUEST CLEARED · +${q.xp} XP`)}
function questMarkup(q){return `<div class="quest ${q.done?'done':''}"><div class="icon-box">${q.icon}</div><div class="quest-info"><b>${q.title} ${q.done?'✓':''}</b><small>${q.desc}<br>${q.detail}</small></div><span class="xp-tag">+${q.xp} XP</span><button class="btn ${q.done?'':'primary'}" ${q.done?'disabled':''} onclick="completeQuest('${q.id}')">${q.done?'Completed':'Complete'}</button></div>`}
function renderQuests(){let target=document.querySelector('#quest-list');if(target)target.innerHTML=currentQuests().map(questMarkup).join('');let done=document.querySelector('#today-count');if(done)done.textContent=currentDone().length;let xp=document.querySelector('#today-xp');if(xp)xp.textContent=currentQuests().filter(q=>q.done).reduce((n,q)=>n+q.xp,0)}
function renderAchievements(){let target=document.querySelector('#badge-grid');if(target)target.innerHTML=achievements.map(a=>{let unlocked=a.test(state);return `<div class="badge ${unlocked?'':'locked'}"><div class="emoji">${a.icon}</div><b>${a.name} ${unlocked?'✓':'🔒'}</b><p>${a.desc}</p><p class="${unlocked?'lime':''}">${unlocked?'UNLOCKED':'LOCKED'}</p></div>`}).join('')}
function renderLeaderboard(){let target=document.querySelector('#leaderboard-body');if(!target)return;let rows=[{name:'NOVA_07',xp:2450},{name:'PIXELPULSE',xp:1825},{name:'ZENITH',xp:1400},{name:state.name||'PLAYER ONE',xp:state.xp,you:true},{name:'QUESTFOX',xp:650}].sort((a,b)=>b.xp-a.xp);target.innerHTML=rows.map((r,i)=>`<tr ${r.you?'style="background:#c4ff3d0b"':''}><td class="rank">#${i+1}</td><td><b>${r.name}${r.you?' (you)':''}</b></td><td>${r.xp.toLocaleString()} XP</td><td>LVL ${levelFor(r.xp)}</td></tr>`).join('')}
function renderProfile(){let input=document.querySelector('#name-input');if(input)input.value=state.name;let initials=document.querySelector('#avatar-letter');if(initials)initials.textContent=(state.name||'P').trim().charAt(0).toUpperCase();let total=document.querySelector('#profile-total');if(total)total.textContent=state.completedTotal;let best=document.querySelector('#profile-best');if(best)best.textContent=state.bestStreak}
function renderPage(){renderShared();renderQuests();renderAchievements();renderLeaderboard();renderProfile();let daily=document.querySelector('#daily-status');if(daily)daily.textContent=`${currentDone().length} of ${questData.length} quests completed today`;let todayBar=document.querySelector('#today-progress');if(todayBar)todayBar.style.width=(currentDone().length/questData.length*100)+'%';let badgeCount=document.querySelector('#badges-count');if(badgeCount){let n=achievements.filter(a=>a.test(state)).length;badgeCount.textContent=n;let bp=document.querySelector('#badges-progress');if(bp)bp.style.width=(n/achievements.length*100)+'%';}let total=document.querySelector('#dashboard-completed');if(total)total.textContent=state.completedTotal;let level=document.querySelector('#level-number');if(level)level.textContent=String(levelFor(state.xp)).padStart(2,'0');}
document.addEventListener('DOMContentLoaded',()=>{renderPage();document.querySelectorAll('[data-save-name]').forEach(b=>b.addEventListener('click',()=>{let input=document.querySelector('#name-input');let name=(input?.value||'').trim().replace(/[<>]/g,'').slice(0,18);if(name){state.name=name.toUpperCase();save();renderProfile();toast('PLAYER PROFILE UPDATED')}}));document.querySelectorAll('[data-reset]').forEach(b=>b.addEventListener('click',()=>{if(confirm('Reset all LEVELUP progress on this device? This cannot be undone.')){state=fresh();save();renderPage();toast('DEMO PROGRESS RESET')}}))});


// Coach Mode state is stored separately from XP so personal planning never affects points.
const COACH_KEY='levelup_coach_state';
const coachTips=[
 ["Consistency beats intensity you can\'t maintain.",'Start small enough that you can repeat it. Rest, school, family, and fun all belong in the plan.'],
 ['You do not need a perfect day.','One manageable action is progress. If today is busy, shrink the plan instead of giving up.'],
 ['Recovery is part of training.','Sleep, breaks, meals, hydration, and relaxed time help you feel ready for tomorrow.'],
 ['Focus on what you can control.','Your effort, attention, and next choice matter more than comparing your progress with someone else.'],
 ['A reset is not a failure.','If you miss a day, begin again when you can. You do not owe the plan a punishment workout or late-night catch-up.'],
 ['Make the goal fit your life.','Schoolwork, friendships, hobbies, and family time matter too. A good plan leaves room for all of them.']
];
const coachGoals={
 balanced:['Move in a way I enjoy','Spend 15 minutes learning','Take a screen break','Make or practise something','Leave time to rest'],
 movement:['Choose a safe activity I enjoy','Warm up gently before activity','Take breaks when I need them','Notice how movement makes me feel','Make room for recovery'],
 learning:['Pick one clear study task','Try one focused work session','Read something interesting','Put distractions away for a short while','Take a real break between tasks'],
 creative:['Choose something to create','Practise a skill for a little while','Try one new idea','Share or save what I made','Notice effort instead of perfection']
};
function loadCoach(){try{return {...{focus:'balanced',checked:[],energy:'',note:'',checkinDate:''},...JSON.parse(localStorage.getItem(COACH_KEY)||'{}')}}catch{return {focus:'balanced',checked:[],energy:'',note:'',checkinDate:''}}}
let coachState=loadCoach();
function saveCoach(){localStorage.setItem(COACH_KEY,JSON.stringify(coachState))}
function renderCoach(){
 const plan=document.querySelector('#coach-plan');if(!plan)return;
 document.querySelectorAll('[data-focus]').forEach(b=>b.classList.toggle('selected',b.dataset.focus===coachState.focus));
 const goals=coachGoals[coachState.focus]||coachGoals.balanced;
 plan.innerHTML=goals.map((g,i)=>`<label class="plan-item ${coachState.checked.includes(i)?'checked':''}"><input type="checkbox" data-goal="${i}" ${coachState.checked.includes(i)?'checked':''}><span>${g}</span></label>`).join('');
 const n=coachState.checked.length;const bar=document.querySelector('#coach-plan-progress');if(bar)bar.style.width=(n/goals.length*100)+'%';const label=document.querySelector('#coach-plan-label');if(label)label.textContent=`${n} of ${goals.length} goals checked`;
 document.querySelectorAll('[data-energy]').forEach(b=>b.classList.toggle('selected',b.dataset.energy===coachState.energy));
 const feedback=document.querySelector('#energy-feedback');if(feedback){const tips={low:'Keep it gentle today: choose one small task, take a break, and let rest be enough.',okay:'A steady pace may fit today. Choose one priority and leave space for breaks.',good:'Great—use that energy on something meaningful, but remember you can still pause when you need to.'};feedback.textContent=tips[coachState.energy]||'Choose an energy check-in to get a gentle suggestion.'}
 const note=document.querySelector('#coach-note');if(note)note.value=coachState.note||'';
 const status=document.querySelector('#checkin-status');if(status&&coachState.checkinDate===today())status.textContent='Your check-in for today is saved on this device.';
}
function initCoach(){if(!document.querySelector('#focus-options'))return;
 document.querySelectorAll('[data-focus]').forEach(b=>b.addEventListener('click',()=>{coachState.focus=b.dataset.focus;coachState.checked=[];saveCoach();renderCoach()}));
 document.querySelector('#coach-plan').addEventListener('change',e=>{if(!e.target.matches('[data-goal]'))return;const i=Number(e.target.dataset.goal);coachState.checked=e.target.checked?[...new Set([...coachState.checked,i])]:coachState.checked.filter(x=>x!==i);saveCoach();renderCoach()});
 document.querySelector('#reset-coach-plan').addEventListener('click',()=>{coachState.checked=[];saveCoach();renderCoach();toast('WEEKLY CHECKLIST RESET')});
 document.querySelectorAll('[data-energy]').forEach(b=>b.addEventListener('click',()=>{coachState.energy=b.dataset.energy;saveCoach();renderCoach()}));
 document.querySelector('#save-checkin').addEventListener('click',()=>{coachState.note=(document.querySelector('#coach-note').value||'').trim().slice(0,140);coachState.checkinDate=today();saveCoach();renderCoach();toast('CHECK-IN SAVED')});
 document.querySelector('#new-coach-tip').addEventListener('click',()=>{let i=Math.floor(Math.random()*coachTips.length);document.querySelector('#coach-message').textContent=coachTips[i][0];document.querySelector('#coach-submessage').textContent=coachTips[i][1]});
 renderCoach();
}
document.addEventListener('DOMContentLoaded',initCoach);
